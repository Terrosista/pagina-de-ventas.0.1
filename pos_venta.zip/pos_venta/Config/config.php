<?php

const base_url="http://localhost/pos_venta/";



?>