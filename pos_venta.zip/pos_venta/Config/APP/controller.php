<?php

class controller
{ 
protected $views, $model;
 public function __construct()
 {   $this->views = new views();
    $this->cargarmodel();
 } 


    public function cargarmodel()
    {

        $model = get_class($this) . "model";
        $ruta = "Models/" . $model . ".php";
        if (file_exists($ruta)) {
            require_once $ruta;
            $this->$model = new $model();
        }
    }
}


?>