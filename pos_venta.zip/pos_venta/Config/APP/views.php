
<?php

class views
{
    public function getView($controlador, $vista)
    {

        $controlador = get_class($controlador);
        if ($controlador == "home") {

            $vista = "views/" . $vista . ".php";
        } else {
            $vista = "views/" . $controlador . "/" . $vista . ".php";
        }
        require $vista;
    }
}
?>