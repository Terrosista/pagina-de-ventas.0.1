<?php
require_once"Config/config.php";
 $ruta= !empty( $_GET['url']) ? $_GET['url'] : "Home/index";
$arry = explode("/",$ruta);
$controller=$arry[0];
$metodo= "index";
$parametro="";
if(!empty($arry[1])){

    if(!empty($arry[1])!= ""){
 
       $metodo=$arry[1];

    }   
}

if(!empty($arry[2])){

    if(!empty($arry[2])!= ""){
     for($i=2; $i<count($arry); $i++){
       $parametro.= $arry[$i].",";

     }
      $parametro= trim($parametro, ";");
    }   
}
require_once "Config/APP/autoload.php";

$dirController = "controllers/" . $controller . ".php";

// Verificar si el archivo del controlador existe
if (file_exists($dirController)) {
    require_once $dirController;
    
    // Crear una instancia del controlador
    $controllerInstance = new $controller();
    
    // Verificar si el método existe en el controlador
    if (method_exists($controllerInstance, $metodo)) {
        // Llamar al método del controlador
        $controllerInstance->$metodo($parametro);
    } else {
        // Manejar el error si el método no existe
        echo "El método solicitado no existe en el controlador.";
    }
} else {
    // Manejar el error si el archivo del controlador no existe
    echo "El archivo del controlador no existe.";
}


?>