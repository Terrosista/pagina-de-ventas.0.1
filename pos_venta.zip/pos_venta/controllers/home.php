<?php

class home extends controller{

public function index(){
   // echo "esta funcionado  el metodo";
   $this->views->getView($this,"index");


}
} 
?>